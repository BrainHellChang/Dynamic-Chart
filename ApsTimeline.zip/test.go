package main

import (
	"net/http"

	"github.com/julienschmidt/httprouter"
)

func test(writer http.ResponseWriter, request *http.Request, params httprouter.Params) {
	logInfo("MAIN", "Serving homepage")
	http.ServeFile(writer, request, "./html/test.html")
}
