package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"time"

	"github.com/julienschmidt/httprouter"
)

type TimelineInput struct {
	Date int64
}

type TimelineData struct {
	StartDate       int64
	EndDate         int64
	StartDateString string
	EndDateString   string
	Work            bool
	Duration        int
	G               int
	W               int
	MoNo            string
}
type TimelineOutput struct {
	Result         string
	ProductionData []TimelineData
}

func getTimeLineData(writer http.ResponseWriter, request *http.Request, params httprouter.Params) {
	logInfo("MAIN", "Timeline function called")
	var data TimelineInput
	err := json.NewDecoder(request.Body).Decode(&data)
	if err != nil {
		logError("MAIN", "Error parsing data: "+err.Error())
		var responseData TimelineOutput
		responseData.Result = "nok: " + err.Error()
		writer.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(writer).Encode(responseData)
		logInfo("MAIN", "Parsing data ended")
		return
	}

	initialTime := time.Unix(data.Date/1000, 0)
	var productionData []TimelineData

	endTime := initialTime.Add(10 * (time.Hour * 24))
	randomGauge := 0
	randomWidth := 0
	moNoIndex := 0
	moNoString := ""
	work := !(rand.Intn(7) == 0) // 0 이면 다운타임
	for initialTime.Before(endTime) {
		randomDuration := rand.Intn(60) + 10

		if work {
			randomGauge = 600 + rand.Intn(1000) + 1
			randomWidth = 7000 + rand.Intn(10000) + 1
			moNoString = fmt.Sprintf("MO%05d", moNoIndex)
			moNoIndex++
		} else {
			randomGauge = 600
			randomWidth = 7000
			moNoString = "DownTim"
		}

		nextTime := initialTime.Add(time.Duration(randomDuration) * time.Minute)

		productionData = append(productionData,
			TimelineData{
				StartDate:       initialTime.Unix(),
				EndDate:         nextTime.Unix(),
				StartDateString: initialTime.Format("2006-01-02T15:04:05"),
				EndDateString:   nextTime.Format("2006-01-02T15:04:05"),
				Duration:        randomDuration,
				G:               randomGauge,
				W:               randomWidth,
				Work:            work,
				MoNo:            moNoString,
			})

		if work {
			work = !(rand.Intn(7) == 0)
		} else {
			work = true
		}
		initialTime = nextTime
	}

	var responseData TimelineOutput
	responseData.Result = "ok"
	responseData.ProductionData = productionData

	writer.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(writer).Encode(responseData)
	logInfo("MAIN", "Parsing data ended successfully")
}
